using UnityEngine;

namespace TarodevController.Demo
{
    [CreateAssetMenu]
    public class TaroTile : RuleTile
    {
    }
}